package com.example.server_connect;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.media.audiofx.BassBoost;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;

import android.provider.Settings;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.T;
import static android.view.View.Y;

public class MainActivity<pivate> extends AppCompatActivity {
    TextView data, title;
    Button button;
    private Handler handler=new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setContentView(R.layout.activity_main);
        data = (TextView) findViewById(R.id.showdata);
        title = (TextView) findViewById(R.id.title);
        button = (Button) findViewById(R.id.go_map);
        Context contex = getApplicationContext();

        title.setText(getResources().getString(R.string.title));
        button.setText(getResources().getString(R.string.button_text));
data.setMovementMethod(new ScrollingMovementMethod());

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checklocation(getApplicationContext());

            }
        });

        //  loadlocate();

        fetchdata();

    }
//data fetch................................
    void fetchdata() {
        String myurl = "https://cichlid-marbles.000webhostapp.com/Api/connect.php";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(myurl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = (JSONObject) response.get(i);
                        data.setText(data.getText() + "\n........................\n" + jsonObject.getString("id") + "\n" + jsonObject.getString("name") + "\n" + jsonObject.getString("email") + "\n" + jsonObject.getString("phone"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("volleylog", error);
            }
        });
        com.example.server_connect.AppController.getInstance().addToRequestQueue(jsonArrayRequest);
        Toast.makeText(getApplicationContext(), "server connection sucess", Toast.LENGTH_LONG).show();
    }



 /*  private void showdilog() {
        final String[] list = {"English", "বাংলা"};
        AlertDialog.Builder mbuilder = new AlertDialog.Builder(MainActivity.this);
        mbuilder.setTitle("Choose Your Language");
        mbuilder.setSingleChoiceItems(list, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    setlang("en");

                } else if (which == 1) {
                    setlang("bn");

                }
                dialog.dismiss();
               // Intent i=new Intent(getApplicationContext(),signup_activity.class);
                //startActivity(i);
            }
        });
        AlertDialog mdilog = mbuilder.create();
        mdilog.show();
    }

    private void setlang(String s) {
        Locale locale = new Locale(s);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor = (SharedPreferences.Editor) getPreferences(Activity.MODE_PRIVATE).edit();
        editor.putString("my_lang", s);
        editor.apply();
        title.setText(getResources().getString(R.string.title));
        button.setText(getResources().getString(R.string.button_text));
    }

    private void loadlocate() {
        SharedPreferences preferences = getPreferences(Activity.MODE_PRIVATE);
        String languages = preferences.getString("my_lang", "");
        setlang(languages);
    } */

    @TargetApi(Build.VERSION_CODES.P)

    private void checklocation( Context context) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
              if (!islocation_enable(context)) {

                  builder.setMessage("Turn on Location First!");
                  builder.setTitle("Location is Off");
                  builder.setIcon(R.drawable.ic_location_off_black_24dp);

                  builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {

                          Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                          startActivity(intent);

                      }
                  });
                  builder.setNegativeButton(R.string.close, new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {

                          Toast.makeText(getApplicationContext(), "This feature is not accessable", Toast.LENGTH_LONG).show();

                      }

                  });

                  builder.create();
                  builder.setCancelable(false);
                  builder.show();

              }else {
                  Intent i=new Intent(MainActivity.this,MapsActivity.class);
                  startActivity(i);
              }

    }

    public static boolean islocation_enable(Context context){
        int locationmode=0;
        String locationproviders;

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT) {
            try {
                locationmode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);
            } catch (Settings.SettingNotFoundException e) {
                 e.printStackTrace();
                 return false;
            }
            return locationmode != Settings.Secure.LOCATION_MODE_OFF;
        }else {

            locationproviders =Settings.Secure.getString(context.getContentResolver(),Settings.Secure.LOCATION_PROVIDERS_ALLOWED);

        return !TextUtils.isEmpty(locationproviders);
        }
    }
}


