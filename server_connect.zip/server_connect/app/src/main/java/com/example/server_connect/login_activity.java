package com.example.server_connect;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.example.server_connect.R.string.login;

public class login_activity extends AppCompatActivity {
TextInputLayout t[];
Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);
        t=new TextInputLayout[2];
        t[0]=(TextInputLayout)findViewById(R.id.ph_e);
        t[1]=(TextInputLayout)findViewById(R.id.pass_login);
        login=(Button) findViewById(R.id.login);

initilixetext();
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                InputMethodManager inputManager=(InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputManager.hideSoftInputFromWindow(v.getWindowToken(),0);
                if(checkfilds()){

                    loginuser();

                }

            }
        });

    }

    private void loginuser(){
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.login_process_title));
        progressDialog.setMessage(getString(R.string.wait_dilog));
        progressDialog.show();
        login.setVisibility(View.GONE);
        String loginurl="https://cichlid-marbles.000webhostapp.com/Api/login.php";
        StringRequest stringRequest=new StringRequest(Request.Method.POST, loginurl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("mylog",response);
                try {
                     JSONObject jsonObject=new JSONObject(response);

                    String sucess=jsonObject.getString("sucess");
                    if(sucess.equals("1")){
                       final String name=jsonObject.getString("name");
                       final String msg=jsonObject.getString("msg");
                        progressDialog.dismiss();

                       progressbar progressbar=new progressbar(6000,login_activity.this,msg,getString(R.string.welcome)+"  "+name);
                       progressbar.run();



                                Intent i=new Intent(login_activity.this,MainActivity.class);
                                startActivity(i);
                        login.setVisibility(View.VISIBLE);

                    }else {
                        progressDialog.dismiss();
                        login.setVisibility(View.VISIBLE);
                        final AlertDialog.Builder builder=new AlertDialog.Builder(login_activity.this);
                        builder.setCancelable(false);
                        builder.setTitle(R.string.login_fail);
                        builder.setMessage(R.string.login_failmsg);
                        builder.setPositiveButton(R.string.button_signin, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                Intent i=new Intent(login_activity.this,signup_activity.class);
                                startActivity(i);
                            }
                        });
                        builder.setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        builder.create();
                        builder.show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Error" + e.toString(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                    login.setVisibility(View.VISIBLE);
                }


            }
        },new Response.ErrorListener()

        {
            @Override
            public void onErrorResponse (VolleyError error){
                Toast.makeText(getApplicationContext(), "Register error" + error.toString(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
                login.setVisibility(View.VISIBLE);
            }}){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("phone_or_email",t[0].getEditText().getText().toString());
                params.put("password",t[1].getEditText().getText().toString());
             return  params;
            }
        };
        com.example.server_connect.AppController.getInstance().addToRequestQueue(stringRequest);

    }


    private  void initilixetext(){
        t[0].setHint(getString(R.string.phone_or_email));
        t[1].setHint(getString(R.string.password));
        login.setText(R.string.login);
    }
    private boolean checkfilds() {


        boolean result = true;
        for (int i = 0; i <t.length;i++) {
            if(t[i].getEditText().getText().toString().equals("")){
                t[i].getEditText().setError(getString(R.string.helper));
                result=false;
            }

        }
        return  result;
    }
    private void formattxt(){
        t[0].getEditText().setText("");
        t[1].getEditText().setText("");
    }
}
