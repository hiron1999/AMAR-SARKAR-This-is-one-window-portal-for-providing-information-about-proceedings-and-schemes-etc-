package com.example.server_connect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class startingactivity extends AppCompatActivity {

Button signup,login;
TextView heading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_startingactivity);
        signup=(Button)findViewById(R.id.go_signup);
        signup=(Button)findViewById(R.id.go_login);
        heading=(TextView)findViewById(R.id.welcome_text);
    }

    public void goto_login(View view) {
        Intent i=new Intent(this,login_activity.class);
        startActivity(i);
    }

    public void goto_signup(View view) {
        Intent i=new Intent(this,signup_activity.class);
        startActivity(i);
    }
}
